# Implement Client Script & UI Policy (Incident)

## ServiceNow Micro Project

This repository contains the phase-wise project submission for the ServiceNow project **Implement Client Script & UI Policy (Incident)**.

### Project Purpose
The project demonstrates how ServiceNow UI Policies and Client Scripts can be used on Incident records to enforce conditional field behavior, automate values, validate submission, and control list-based updates.

## Technologies / Skills
- ServiceNow
- Incident Management
- UI Policy
- UI Policy Actions
- Client Scripts
- Form Validation

## Core Implementation

### UI Policy
**High Impact Control**
- Table: Incident
- Condition: Impact is 1 – High
- Reverse if false: True

### UI Policy Actions
- Assignment group → Mandatory
- Urgency → Read-only

### Client Scripts
1. **Auto set urgency for high impact**
   - Type: onChange
   - Field: Impact
2. **Prevent save if Assigned To missing**
   - Type: onSubmit
3. **Prevent state change via list edit**
   - Type: onCellEdit
   - Field: State

## Eight Project Phases

1. Brainstorming & Ideation
2. Requirement Analysis
3. Project Design
4. Project Planning
5. Project Development
6. Project Testing
7. Project Documentation
8. Project Demonstration

## Testing Summary

The project tests:
- High Impact conditional behavior
- Mandatory Assignment group
- Automatic High Urgency
- Read-only Urgency
- Save prevention when Assigned To is empty
- Successful save when Assigned To is supplied
- Reverse condition when Impact changes away from High
- State list-edit blocking
- State form-based update

## Demo Video
Google Drive link: **ADD YOUR PUBLIC GOOGLE DRIVE LINK HERE**

## Team Members
- Member 1: ADD NAME
- Member 2: ADD NAME
- Member 3: ADD NAME
- Member 4: ADD NAME

## Faculty
Faculty Name: **ADD NAME**

## Submission Note
Screenshots from the actual ServiceNow instance should be placed in the `Screenshots` folders. Replace placeholders with the final evidence before making the repository public.
