# SmartBridge Submission Checklist

## GitHub
- [ ] Repository is Public
- [ ] README.md completed
- [ ] Phase 1 uploaded
- [ ] Phase 2 uploaded
- [ ] Phase 3 uploaded
- [ ] Phase 4 uploaded
- [ ] Phase 5 uploaded
- [ ] Phase 6 uploaded
- [ ] Phase 7 uploaded
- [ ] Phase 8 uploaded
- [ ] Actual ServiceNow screenshots added
- [ ] Team member names added
- [ ] Faculty name added

## Demo Video
- [ ] Screen sharing included
- [ ] Voice-over included
- [ ] Project name explained
- [ ] Purpose explained
- [ ] Benefits explained
- [ ] Working process demonstrated
- [ ] Final output demonstrated
- [ ] Video uploaded to Google Drive
- [ ] Sharing set to Anyone with the link → Viewer
- [ ] Google Drive link added to README.md and Demo-Video-Link.txt

## Before Final Submission
- [ ] Replace all ADD NAME placeholders
- [ ] Replace all PASS / UPDATE test results
- [ ] Add real screenshots
- [ ] Add public GitHub URL
- [ ] Add public Google Drive demo URL
